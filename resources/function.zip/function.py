import json
from time import ctime
import requests
from bs4 import BeautifulSoup


print('Loading function')


def lambda_handler(event, context):
#def scraper():
    #print("Received event: " + json.dumps(event, indent=2))
    html = requests.get('https://www.naver.com/').text
    executed_time = ctime() # value1

    soup = BeautifulSoup(html, 'html.parser')
    kw_list = soup.find("ul", attrs={"class":"ah_l"})
    all_li = kw_list.find_all("span", attrs={"class":"ah_k"})

    result = []
    for li in all_li:
        result.append(li.text)

    #result = ['','','']
    #{"executed": "2019-01-12 17:25:00",
    # "keywords": ["스카이캐슬..",""] }

    data = {
        "executed": executed_time,
        "keywords": result,
    }

    return data  # Echo back the first key value
    #raise Exception('Something went wrong')
#if __name__ == '__main__':
#    result = scraper()
#    print(result)
